<?php
session_start();
include 'connect.php';

if (isset($_POST['prijava'])) {
    $prijavaImeKorisnika = $_POST['username'];
    $prijavaLozinkaKorisnika = $_POST['lozinka'];

    $sql = "SELECT korisnicko_ime, lozinka, razina FROM korisnik WHERE korisnicko_ime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $prijavaImeKorisnika);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, $levelKorisnika);
        mysqli_stmt_fetch($stmt);
        
        if (password_verify($prijavaLozinkaKorisnika, $lozinkaKorisnika) && mysqli_stmt_num_rows($stmt) > 0) {
            $_SESSION['korisnicko_ime'] = $imeKorisnika;
            $_SESSION['razina'] = $levelKorisnika;
            if ($levelKorisnika == 1) {
                header("Location: administracija.php");
                exit();
            } else {
                echo "Bok $imeKorisnika! Uspješno ste prijavljeni, ali niste administrator.";
            }
        } else {
            echo "Neispravno korisničko ime ili lozinka. Molimo registrirajte se.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Prijava</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form method="POST" action="">
        <label for="username">Korisničko ime:</label>
        <input type="text" name="username" id="username" required>
        <label for="lozinka">Lozinka:</label>
        <input type="password" name="lozinka" id="lozinka" required>
        <button type="submit" name="prijava">Prijava</button>
    </form>
    <p>Nemate račun? <a href="registracija.php">Registrirajte se</a></p>
</body>
</html>
