<?php
include 'connect.php';
define('UPLPATH', 'slike/');

$kategorija = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategorija</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="slike/logo.png" alt="Sopitas.com">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="kategorija.php?id=glazba">Música</a></li>
                    <li><a href="kategorija.php?id=sport">Deportes</a></li>
                    <li><a href="administracija.php">Administracija</a></li>
                    <li><a href="unos.html">Unos Vijesti</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main>
        <section class="category">
            <h2 class="category-title"><?php echo ucfirst($kategorija); ?></h2>
            <div class="articles">
                <?php
                $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='$kategorija'";
                $result = mysqli_query($dbc, $query);
                while ($row = mysqli_fetch_array($result)) {
                    echo '<article>
                            <a href="clanak.php?id='.$row['id'].'">
                                <img src="' . UPLPATH . $row['slika'] . '" alt="'.$row['naslov'].'">
                                <h3>'.$row['naslov'].'</h3>
                                <p>'.$row['datum'].'</p>
                            </a>
                          </article>';
                }
                ?>
            </div>
        </section>
    </main>
    <footer>
        <p>Autor: Paula Jagodić | Email: pjagodic@tvz.hr | Godina: 2024</p>
    </footer>
</body>
</html>
