<?php
include 'connect.php';

if (isset($_POST['registracija'])) {
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $username = $_POST['username'];
    $lozinka = $_POST['pass'];
    $hashed_password = password_hash($lozinka, PASSWORD_BCRYPT);
    $razina = 0;

    $sql = "SELECT korisnicko_ime FROM korisnik WHERE korisnicko_ime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        if (mysqli_stmt_num_rows($stmt) > 0) {
            $msg = "Korisničko ime već postoji!";
        } else {
            $sql = "INSERT INTO korisnik (ime, prezime, korisnicko_ime, lozinka, razina) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_stmt_init($dbc);
            if (mysqli_stmt_prepare($stmt, $sql)) {
                mysqli_stmt_bind_param($stmt, 'ssssd', $ime, $prezime, $username, $hashed_password, $razina);
                mysqli_stmt_execute($stmt);
                echo "Korisnik je uspješno registriran!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registracija</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form method="POST" action="">
        <label for="ime">Ime:</label>
        <input type="text" name="ime" id="ime" required>
        <label for="prezime">Prezime:</label>
        <input type="text" name="prezime" id="prezime" required>
        <label for="username">Korisničko ime:</label>
        <input type="text" name="username" id="username" required>
        <label for="pass">Lozinka:</label>
        <input type="password" name="pass" id="pass" required>
        <label for="passRep">Ponovite lozinku:</label>
        <input type="password" name="passRep" id="passRep" required>
        <button type="submit" name="registracija">Registracija</button>
    </form>
</body>
</html>
