<?php
session_start();

if (!isset($_SESSION['korisnicko_ime']) || $_SESSION['razina'] != 1) {
    echo "Nemate dovoljna prava za pristup ovoj stranici.";
    exit();
}

include 'connect.php';
define('UPLPATH', 'slike/');

if (isset($_POST['delete'])) {
    $id = $_POST['id'];
    $query = "DELETE FROM vijesti WHERE id=$id";
    $result = mysqli_query($dbc, $query);
}

if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $about = $_POST['about'];
    $content = $_POST['content'];
    $category = $_POST['category'];
    $archive = isset($_POST['archive']) ? 1 : 0;

    $picture = $_FILES['pphoto']['name'];
    if ($picture) {
        $target_dir = 'slike/'.$picture;
        move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);
        $query = "UPDATE vijesti SET naslov='$title', sazetak='$about', tekst='$content', slika='$picture', kategorija='$category', arhiva='$archive' WHERE id=$id";
    } else {
        $query = "UPDATE vijesti SET naslov='$title', sazetak='$about', tekst='$content', kategorija='$category', arhiva='$archive' WHERE id=$id";
    }
    $result = mysqli_query($dbc, $query);
}

$query = "SELECT * FROM vijesti";
$result = mysqli_query($dbc, $query);
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administracija Vijesti</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="slike/logo.png" alt="Sopitas.com">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="kategorija.php?id=glazba">Música</a></li>
                    <li><a href="kategorija.php?id=sport">Deportes</a></li>
                    <li><a href="administracija.php">Administracija</a></li>
                    <li><a href="unos.html">Unos Vijesti</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main>
        <?php while ($row = mysqli_fetch_array($result)): ?>
            <form enctype="multipart/form-data" action="" method="POST">
                <div class="form-item">
                    <label for="title">Naslov vijesti:</label>
                    <input type="text" name="title" class="form-field-textual" value="<?php echo $row['naslov']; ?>">
                </div>
                <div class="form-item">
                    <label for="about">Kratki sadržaj vijesti (do 50 znakova):</label>
                    <textarea name="about" cols="30" rows="10" class="form-field-textual"><?php echo $row['sazetak']; ?></textarea>
                </div>
                <div class="form-item">
                    <label for="content">Sadržaj vijesti:</label>
                    <textarea name="content" cols="30" rows="10" class="form-field-textual"><?php echo $row['tekst']; ?></textarea>
                </div>
                <div class="form-item">
                    <label for="pphoto">Slika:</label>
                    <input type="file" name="pphoto" class="form-field-textual">
                    <br><img src="<?php echo UPLPATH . $row['slika']; ?>" width="100px">
                </div>
                <div class="form-item">
                    <label for="category">Kategorija vijesti:</label>
                    <select name="category" class="form-field-textual">
                        <option value="sport" <?php if ($row['kategorija'] == 'sport') echo 'selected'; ?>>Sport</option>
                        <option value="kultura" <?php if ($row['kategorija'] == 'kultura') echo 'selected'; ?>>Kultura</option>
                        <option value="glazba" <?php if ($row['kategorija'] == 'glazba') echo 'selected'; ?>>Glazba</option>
                        <option value="tehnologija" <?php if ($row['kategorija'] == 'tehnologija') echo 'selected'; ?>>Tehnologija</option>
                    </select>
                </div>
                <div class="form-item">
                    <label>Spremiti u arhivu:
                        <input type="checkbox" name="archive" <?php if ($row['arhiva'] == 1) echo 'checked'; ?>/> Arhiviraj?
                    </label>
                </div>
                <div class="form-item">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <button type="reset">Poništi</button>
                    <button type="submit" name="update">Izmjeni</button>
                    <button type="submit" name="delete">Izbriši</button>
                </div>
            </form>
        <?php endwhile; ?>
    </main>
    <footer>
        <p>Autor: Paula Jagodić | Email: pjagodic@tvz.hr | Godina: 2024</p>
    </footer>
</body>
</html>
