<?php
include 'connect.php';
define('UPLPATH', 'slike/');

$id = $_GET['id'];
$query = "SELECT * FROM vijesti WHERE id=$id";
$result = mysqli_query($dbc, $query);
$row = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $row['naslov']; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="slike/logo.png" alt="Sopitas.com">
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="kategorija.php?id=glazba">Música</a></li>
                    <li><a href="kategorija.php?id=sport">Deportes</a></li>
                    <li><a href="administracija.php">Administracija</a></li>
                    <li><a href="unos.html">Unos Vijesti</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <main>
        <section class="clanak">
            <h1><?php echo $row['naslov']; ?></h1>
            <p class="date"><?php echo $row['datum']; ?></p>
            <img src="<?php echo UPLPATH . $row['slika']; ?>" alt="<?php echo $row['naslov']; ?>">
            <p class="about"><?php echo $row['sazetak']; ?></p>
            <p class="sadrzaj"><?php echo $row['tekst']; ?></p>
        </section>
    </main>
    <footer>
        <p>Autor: Paula Jagodić | Email: pjagodic@tvz.hr | Godina: 2024</p>
    </footer>
</body>
</html>
