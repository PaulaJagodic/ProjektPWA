-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2024 at 12:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vijesti`
--

-- --------------------------------------------------------

--
-- Table structure for table `vijesti`
--

CREATE TABLE `vijesti` (
  `id` int(11) NOT NULL,
  `datum` date DEFAULT NULL,
  `naslov` varchar(255) DEFAULT NULL,
  `sazetak` varchar(255) DEFAULT NULL,
  `tekst` text DEFAULT NULL,
  `slika` varchar(255) DEFAULT NULL,
  `kategorija` varchar(50) DEFAULT NULL,
  `arhiva` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vijesti`
--

INSERT INTO `vijesti` (`id`, `datum`, `naslov`, `sazetak`, `tekst`, `slika`, `kategorija`, `arhiva`) VALUES
(1, '2019-05-17', '¡Chance The Rapper está de vuelta con “Groceries”!', 'Mayo 17, 2019', 'Chance the Rapper released his new single \"Groceries\" on May 17, 2019.', 'clanak1.jpg', 'glazba', 0),
(2, '2019-05-17', '¡Escucha', 'Mayo 17, 2019', 'The Hives released their first song in 4 years, \"I’m Alive\", on May 17, 2019.', 'clanak2.jpg', 'glazba', 0),
(3, '2019-05-17', '“I Am Easy To Find”, el trabajo más puro y personal de The National', 'Mayo 17, 2019', 'The National released their new album \"I Am Easy To Find\" on May 17, 2019.', 'clanak3.jpeg', 'glazba', 0),
(4, '2019-05-18', 'Setién ‘arremetió’ contra Lainez y su falta de juego: “Yo no le regalo nada a nadie”', 'Mayo 18, 2019', 'La Liga is about to end, and Diego Lainez is in the spotlight. Setién confirmed that Lainez will play when he deserves it.', 'clanak4.jpg', 'sport', 0),
(5, '2019-05-18', 'El motivo por el que Lobos BUAP no podría mudarse a Ciudad Juárez', 'Mayo 18, 2019', 'Discussion on why Lobos BUAP might not move to Ciudad Juárez.', 'clanak5.jpeg', 'sport', 0),
(6, '2019-05-18', 'Los goles de Ribery y Robben con los que se despidieron del Bayern Múnich', 'Mayo 18, 2019', 'The goals of Ribery and Robben in their farewell match for Bayern Munich.', 'clanak6.png', 'sport', 0),
(7, '2024-06-14', 'vijest', 'dadadadaddad', 'daadadadadadadadada', 'clanak5.jpeg', 'sport', 0),
(8, '2024-06-13', 'naslov', 'kratki opis kratki', 'asda dsa asd asd asdas das dasd asd aasd a', 'clanak5.jpeg', 'kultura', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vijesti`
--
ALTER TABLE `vijesti`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vijesti`
--
ALTER TABLE `vijesti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
